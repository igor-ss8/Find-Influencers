from django.apps import AppConfig


class InstagramusersConfig(AppConfig):
    name = 'instagramusers'
